package com.example.editfast

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.TextureView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.AbsoluteAlignment
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

/** طبقة في المعاينة: نص / ملصق / تراكب صورة أو فيديو (PIP) مع إطار تحديد ومقابض */
@Composable
internal fun CaptionLayer(vm: EditorViewModel, idx: Int, c: Caption, pos: Long, fw: Int, fh: Int, safe: SafeZone?, selected: Boolean,
                         pip: ExoPlayer, onEdit: () -> Unit) {
    val a = CapAnim.state(c, pos)
    val isVid = c.vid != null
    val bmp = remember(c, fw, fh, a.chars) { if (c.vid != null) null else CapRender.render(c, fw, fh, a.chars).asImageBitmap() }
    val bw = if (isVid) (fw * 0.45f * c.st.size).toInt().coerceAtLeast(8) else bmp!!.width
    val bh = if (isVid) (bw / c.vAspect).toInt().coerceAtLeast(8) else bmp!!.height
    val (x, y) = CapAnim.place(c, bw, bh, fw, fh, safe, a)
    val cx = (x + 1f) / 2f * fw; val cy = (1f - y) / 2f * fh
    val den = LocalDensity.current
    val wDp = with(den) { bw.toDp() }; val hDp = with(den) { bh.toDp() }
    val shape = when (c.mask) { 1 -> CircleShape; 2 -> RoundedCornerShape(18); else -> RectangleShape }
    Box(Modifier.offset { IntOffset((cx - bw / 2f).toInt(), (cy - bh / 2f).toInt()) }
        .size(wDp, hDp).graphicsLayer(scaleX = a.scale, scaleY = a.scale, rotationZ = -a.rot)) {
        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize().graphicsLayer(alpha = a.alpha))
        else Box(Modifier.fillMaxSize().graphicsLayer(alpha = a.alpha).clip(shape)
            .then(if (c.bw > 0f) Modifier.border(with(den) { (c.bw * bw * 0.01f).toDp() }, Color(c.bc), shape) else Modifier)) {
            AndroidView({ ctx -> TextureView(ctx).also { pip.setVideoTextureView(it) } }, Modifier.fillMaxSize())
        }
        Box(Modifier.fillMaxSize()
            .pointerInput(idx) { detectTapGestures { vm.selCap = idx; vm.selClip = false } }
            .pointerInput(idx, selected) {
                if (selected) detectTransformGestures { _, pan, z, _ -> vm.moveCap(idx, pan.x / (fw / 2f), -pan.y / (fh / 2f), z) }
            })
        if (selected) {
            Box(Modifier.fillMaxSize().border(1.5.dp, Color.White))
            Handle(AbsoluteAlignment.TopLeft, -14, -14, RED, Icons.Default.Close, onClick = { vm.removeCaption(idx) })
            if (c.img == null && !isVid) Handle(AbsoluteAlignment.TopRight, 14, -14, Color.White, Icons.Default.Edit, onClick = onEdit)
            Handle(AbsoluteAlignment.BottomRight, 14, 14, Color.White, Icons.Default.OpenInFull,
                Modifier.pointerInput(idx) { detectDragGestures { ch, d -> ch.consume(); vm.updStyle(idx) { it.copy(size = (it.size * (1f + (d.x + d.y) / bw)).coerceIn(0.3f, 4f)) } } })
            if (c.img == null && !isVid && c.tpl == null) {
                Handle(AbsoluteAlignment.CenterRight, 10, 0, Color.White, null,
                    Modifier.pointerInput(idx) { detectDragGestures { ch, d -> ch.consume(); vm.updStyle(idx) { it.copy(maxW = (it.maxW + d.x * 2f / fw).coerceIn(0.2f, 0.98f)) } } })
                Handle(AbsoluteAlignment.CenterLeft, -10, 0, Color.White, null,
                    Modifier.pointerInput(idx) { detectDragGestures { ch, d -> ch.consume(); vm.updStyle(idx) { it.copy(maxW = (it.maxW - d.x * 2f / fw).coerceIn(0.2f, 0.98f)) } } })
            }
        }
    }
}

/** محرر النص المثبّت أسفل الشاشة (على طريقة InShot) */
@Composable
internal fun TextEditor(vm: EditorViewModel, i: Int, c: Caption, fonts: List<FontOpt>, onAddFont: () -> Unit,
                       onCustomColor: ((Int) -> Unit) -> Unit, onDone: () -> Unit, onCancel: () -> Unit) {
    var tab by remember { mutableIntStateOf(3) }
    var sub by remember { mutableIntStateOf(0) }
    val st = c.st
    fun upd(f: (CapStyle) -> CapStyle) = vm.updStyle(i, f)
    Column(Modifier.fillMaxWidth().background(PANEL)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            IconButton(onDone) { Icon(Icons.Default.Check, null, tint = Color.White) }
            IconButton({ tab = 0 }) { Icon(Icons.Default.Opacity, null, tint = if (tab == 0) ACCENT else Color.White) }
            IconButton({ tab = 1 }) { Icon(Icons.Default.FormatAlignCenter, null, tint = if (tab == 1) ACCENT else Color.White) }
            TextButton({ tab = 2 }) { Text("Aa", fontSize = 20.sp, color = if (tab == 2) ACCENT else Color.White) }
            IconButton({ tab = 3 }, Modifier.clip(RoundedCornerShape(8.dp)).background(if (tab == 3) Color(0xFF2C2C36) else Color.Transparent)) {
                Box(Modifier.size(26.dp).clip(CircleShape).background(Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red))))
            }
            IconButton({ tab = 4 }) { Icon(Icons.Default.FormatColorText, null, tint = if (tab == 4) ACCENT else Color(0xFFFF8A65)) }
            IconButton({ tab = 5 }) { Icon(Icons.Default.Keyboard, null, tint = if (tab == 5) ACCENT else Color.White) }
            IconButton(onCancel) { Icon(Icons.Default.Close, null, tint = Color.White) }
        }
        Column(Modifier.heightIn(max = 330.dp).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp).padding(bottom = 10.dp)) {
            when (tab) {
                3 -> {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                        listOf("نص", "الحدود", "ظل", "توهج", "بطاقة", "التعتيم").forEachIndexed { k, n ->
                            Column(Modifier.clickable { sub = k }.padding(vertical = 6.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(n, color = if (sub == k) Color.White else Color.Gray, fontSize = 15.sp)
                                if (sub == k) Box(Modifier.padding(top = 3.dp).size(5.dp).clip(CircleShape).background(Color.White))
                            }
                        }
                    }
                    when (sub) {
                        0 -> Palette(st.color, false, { col -> if (col != null) upd { it.copy(color = col, grad = false) } }) { onCustomColor { col -> upd { it.copy(color = col, grad = false) } } }
                        1 -> {
                            Palette(if (st.outline) st.outlineColor else null, true, { col -> if (col == null) upd { it.copy(outline = false) } else upd { it.copy(outline = true, outlineColor = col) } }) { onCustomColor { col -> upd { it.copy(outline = true, outlineColor = col) } } }
                            if (st.outline) Slider(st.outW, { v -> upd { it.copy(outW = v) } }, valueRange = 0.3f..3f)
                        }
                        2 -> {
                            Palette(if (st.shadow) st.shadowColor else null, true, { col -> if (col == null) upd { it.copy(shadow = false) } else upd { it.copy(shadow = true, shadowColor = col) } }) { onCustomColor { col -> upd { it.copy(shadow = true, shadowColor = col) } } }
                            if (st.shadow) Slider(st.shadowAmt, { v -> upd { it.copy(shadowAmt = v) } }, valueRange = 0.3f..3f)
                        }
                        3 -> Palette(if (st.glow) (if (st.glowColor != 0) st.glowColor else st.color) else null, true, { col -> if (col == null) upd { it.copy(glow = false) } else upd { it.copy(glow = true, glowColor = col) } }) { onCustomColor { col -> upd { it.copy(glow = true, glowColor = col) } } }
                        4 -> {
                            Palette(if (st.boxMode != 0) st.boxColor else null, true, { col -> if (col == null) upd { it.copy(boxMode = 0) } else upd { it.copy(boxMode = if (it.boxMode == 0) 2 else it.boxMode, boxColor = col) } }) { onCustomColor { col -> upd { it.copy(boxMode = if (it.boxMode == 0) 2 else it.boxMode, boxColor = col) } } }
                            if (st.boxMode != 0) {
                                Chips(listOf("مربع", "دائري"), st.boxMode - 1) { k -> upd { it.copy(boxMode = k + 1) } }
                                Slider(st.boxPad, { v -> upd { it.copy(boxPad = v) } }, valueRange = 0.3f..2.5f)
                            }
                        }
                        5 -> { Text("شفافية النص", color = Color.White); Slider(st.opacity, { v -> upd { it.copy(opacity = v) } }, valueRange = 0.1f..1f) }
                    }
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(84.dp, 46.dp).clip(RoundedCornerShape(6.dp)).background(Color.White).clickable { upd { it.copy(boxMode = 0) } }, contentAlignment = Alignment.Center) { Icon(Icons.Default.Block, null, tint = RED) }
                        CARDS.forEach { p ->
                            Box(Modifier.size(84.dp, 46.dp).clip(RoundedCornerShape(if (p.mode == 2) (p.r * 11f).coerceAtMost(23f).dp else 2.dp)).background(Color(p.color))
                                .clickable { upd { it.copy(boxMode = p.mode, boxColor = p.color, boxR = p.r, color = p.text, grad = false) } }, contentAlignment = Alignment.Center) {
                                Text("نص", color = Color(p.text), fontSize = 16.sp)
                            }
                        }
                    }
                }
                2 -> {
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        fonts.forEach { f ->
                            val fam = remember(f) { FontFamily(CapStyle(font = f.font, fontPath = f.path, bold = false).typeface()) }
                            val on = st.font == f.font && st.fontPath == f.path
                            Box(Modifier.size(100.dp, 54.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF2C2C36)).then(if (on) Modifier.border(2.dp, ACCENT, RoundedCornerShape(10.dp)) else Modifier)
                                .clickable { upd { it.copy(font = f.font, fontPath = f.path) } }, contentAlignment = Alignment.Center) {
                                Text("أبجد Abc", fontFamily = fam, color = Color.White, fontSize = 17.sp, maxLines = 1)
                            }
                        }
                        AssistChip(onAddFont, { Text("+ خط") })
                    }
                    Text("الحجم", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Slider(st.size, { v -> upd { it.copy(size = v) } }, valueRange = 0.4f..3f)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(st.bold, { upd { it.copy(bold = !it.bold) } }, { Text("عريض") })
                        FilterChip(st.italic, { upd { it.copy(italic = !it.italic) } }, { Text("مائل") })
                        FilterChip(st.underline, { upd { it.copy(underline = !it.underline) } }, { Text("تسطير") })
                    }
                }
                1 -> {
                    Text("المحاذاة", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Chips(listOf("بداية السطر", "وسط", "نهاية السطر"), st.align) { k -> upd { it.copy(align = k) } }
                    Text("تباعد الأحرف", color = Color.White); Slider(st.spacing, { v -> upd { it.copy(spacing = v) } }, valueRange = 0f..0.5f)
                    Text("تباعد الأسطر", color = Color.White); Slider(st.lineSp, { v -> upd { it.copy(lineSp = v) } }, valueRange = 0.7f..2f)
                    Text("أقصى عرض للنص", color = Color.White); Slider(st.maxW, { v -> upd { it.copy(maxW = v) } }, valueRange = 0.3f..0.95f)
                }
                0 -> {
                    Text("الشفافية", color = Color.White, modifier = Modifier.padding(top = 8.dp)); Slider(st.opacity, { v -> upd { it.copy(opacity = v) } }, valueRange = 0.1f..1f)
                    Text("تدوير النص", color = Color.White); Slider(st.rot, { v -> upd { it.copy(rot = v) } }, valueRange = -180f..180f)
                    Text("الحجم", color = Color.White); Slider(st.size, { v -> upd { it.copy(size = v) } }, valueRange = 0.4f..3f)
                }
                4 -> {
                    Text("قوالب جاهزة", color = Color.White, modifier = Modifier.padding(top = 8.dp))
                    Chips(TEMPLATES.map { it.first }, -1) { k -> val t = TEMPLATES[k].second; upd { s -> t.copy(x = s.x, y = s.y, size = s.size) } }
                    Opt("تعبئة متدرجة", st.grad) { v -> upd { it.copy(grad = v) } }
                    if (st.grad) Swatches(listOf(0xFFFF4081, 0xFFFF6F00, 0xFF6D4AFF, 0xFF00E5FF, 0xFF69F0AE, 0xFFFFFFFF).map { it.toInt() }, st.color2) { v -> upd { it.copy(color2 = v) } }
                    TextButton({ vm.applyStyleToAll(i) }) { Text("تطبيق هذا التنسيق على كل النصوص") }
                }
                5 -> {
                    val fr = remember { FocusRequester() }
                    LaunchedEffect(Unit) { fr.requestFocus() }
                    OutlinedTextField(c.text, { vm.editCaption(i, it) }, Modifier.fillMaxWidth().padding(top = 8.dp).focusRequester(fr))
                }
            }
        }
    }
}
