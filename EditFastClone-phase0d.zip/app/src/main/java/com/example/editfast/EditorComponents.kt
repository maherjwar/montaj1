package com.example.editfast

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.TextureView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.AbsoluteAlignment
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

internal fun fmt(ms: Long) = String.format(Locale.US, "%d:%02d.%d", ms / 60000, (ms / 1000) % 60, (ms / 100) % 10)

/** ينسخ الوسائط إلى مخزن التطبيق كي تبقى متاحة عند إعادة فتح المشروع */
internal fun importMedia(ctx: Context, u: Uri, prefix: String, mime: String): File {
    val ext = android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: if (mime.startsWith("image")) "jpg" else if (mime.startsWith("audio")) "m4a" else "mp4"
    val f = File(File(ctx.filesDir, "media").apply { mkdirs() }, "${prefix}_${System.currentTimeMillis()}.$ext")
    ctx.contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { i.copyTo(it) } }
    return f
}

internal fun videoInfo(path: String): Triple<Long, Float, Boolean> {
    val m = MediaMetadataRetriever()
    return try {
        m.setDataSource(path)
        val d = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
        var w = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toFloat() ?: 9f
        var h = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toFloat() ?: 16f
        val rot = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toInt() ?: 0
        if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
        Triple(d, if (h > 0) w / h else 1f, true)
    } catch (e: Exception) { Triple(0L, 1f, false) } finally { m.release() }
}

@Composable
internal fun Tool(icon: ImageVector, label: String, hi: Boolean = false, tint: Color = Color.Unspecified, onClick: () -> Unit) {
    val t = if (tint != Color.Unspecified) tint else Color(0xFFB8B3C6)
    Column(Modifier.width(56.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(t.copy(alpha = if (hi) 0.28f else 0.15f))
            .border(1.dp, t.copy(alpha = 0.35f), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = t, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.height(3.dp)); Text(label, fontSize = 10.sp, color = Color(0xFFD0CCDC), maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
internal fun Opt(label: String, on: Boolean, set: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f)); Switch(on, set)
    }
}

@Composable
internal fun Swatches(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        colors.forEach { c ->
            Box(Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                .border(if (c == selected) 3.dp else 1.dp, if (c == selected) Color.White else Color.Gray, CircleShape)
                .clickable { onPick(c) })
        }
    }
}

@Composable
internal fun LayerBtn(h: Int, icon: ImageVector, on: Boolean, onClick: () -> Unit) {
    Box(Modifier.height(h.dp).width(34.dp).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = if (on) Color.White else Color(0xFF666670), modifier = Modifier.size(16.dp))
    }
}

@Composable
internal fun Chips(items: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEachIndexed { i, n -> FilterChip(sel == i, { onSel(i) }, { Text(n) }) }
    }
}

@Composable
internal fun Palette(selected: Int?, withNone: Boolean, onPick: (Int?) -> Unit, onCustom: () -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        if (withNone) Box(Modifier.size(40.dp).background(Color.White).clickable { onPick(null) }, contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Block, null, tint = RED)
        }
        PALETTE.forEach { c ->
            Box(Modifier.size(40.dp).background(Color(c)).then(if (c == selected) Modifier.border(3.dp, ACCENT) else Modifier).clickable { onPick(c) })
        }
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(6.dp)).background(Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)))
            .clickable { onCustom() })
    }
}

@Composable
internal fun BoxScope.Handle(al: Alignment, dx: Int, dy: Int, bg: Color, icon: ImageVector?, mod: Modifier = Modifier, onClick: (() -> Unit)? = null) {
    Box(Modifier.align(al).absoluteOffset(dx.dp, dy.dp).size(28.dp).clip(CircleShape).background(bg).then(mod)
        .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier), contentAlignment = Alignment.Center) {
        if (icon != null) Icon(icon, null, tint = if (bg == Color.White) Color.Black else Color.White, modifier = Modifier.size(16.dp))
    }
}

/** شاشة المشروعات */
@Composable
internal fun ProjectsScreen(list: List<ProjectItem>, onOpen: (Long) -> Unit, onNew: () -> Unit, onDelete: (Long) -> Unit, onClose: (() -> Unit)?) {
    var del by remember { mutableStateOf<Long?>(null) }
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 110.dp)
        .pointerInput(Unit) { detectTapGestures { } }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("مشروعاتي", color = Color.White, fontSize = 24.sp, modifier = Modifier.weight(1f))
            if (onClose != null) IconButton(onClose) { Icon(Icons.Default.Close, null, tint = Color.White) }
        }
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth().height(64.dp).clip(RoundedCornerShape(18.dp)).background(Brush.horizontalGradient(listOf(ACCENT, RED)))
            .clickable(onClick = onNew), contentAlignment = Alignment.Center) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Add, null, tint = Color.White); Spacer(Modifier.width(8.dp)); Text("مشروع جديد", color = Color.White, fontSize = 18.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
        if (list.isEmpty()) Text("لا توجد مشروعات محفوظة بعد. يُحفظ عملك تلقائياً.", color = Color.Gray)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list) { p ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(PANEL).clickable { onOpen(p.id) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    val bmp = remember(p.thumb) { p.thumb?.let { BitmapFactory.decodeFile(it)?.asImageBitmap() } }
                    Box(Modifier.size(72.dp, 96.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF2A2A33))) {
                        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    }
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(p.name, color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(p.modified)) + "  •  " + fmt(p.durationMs), color = Color.Gray, fontSize = 12.sp)
                    }
                    IconButton({ del = p.id }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) }
                }
            }
        }
    }
    del?.let { id ->
        AlertDialog(onDismissRequest = { del = null },
            confirmButton = { TextButton({ onDelete(id); del = null }) { Text("حذف") } },
            dismissButton = { TextButton({ del = null }) { Text("إلغاء") } },
            title = { Text("حذف المشروع؟") }, text = { Text("لا يمكن التراجع عن الحذف.") })
    }
}
