package com.example.editfast

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.TextureView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.AbsoluteAlignment
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

internal val SPEEDS = listOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f)
internal val PALETTE = listOf(0xFFFFFFFF, 0xFFCCCCCC, 0xFF999999, 0xFF666666, 0xFF000000, 0xFFFFE0B2, 0xFFFFCC80, 0xFFFFEB3B, 0xFFFFD54F,
    0xFFFF9100, 0xFFFF5252, 0xFFFF1744, 0xFFB71C1C, 0xFFFF4081, 0xFFE040FB, 0xFF7C4DFF, 0xFF6D4AFF, 0xFF448AFF, 0xFF00B0FF,
    0xFF00E5FF, 0xFF1DE9B6, 0xFF69F0AE, 0xFF76FF03, 0xFFFFCDD2).map { it.toInt() }

internal data class CardP(val mode: Int, val color: Int, val text: Int, val r: Float)
internal val CARDS = listOf(
    CardP(1, 0xFFFFEB3B.toInt(), 0xFF000000.toInt(), 0f), CardP(1, 0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0f),
    CardP(2, 0xFFFFFFFF.toInt(), 0xFF000000.toInt(), 2f), CardP(2, 0xFFFFC107.toInt(), 0xFF000000.toInt(), 2f),
    CardP(2, 0xCC000000.toInt(), 0xFFFFFFFF.toInt(), 2f), CardP(2, 0xFFFF1744.toInt(), 0xFFFFFFFF.toInt(), 0.6f),
    CardP(2, 0xFF6D4AFF.toInt(), 0xFFFFFFFF.toInt(), 0.9f), CardP(2, 0xFF69F0AE.toInt(), 0xFF000000.toInt(), 0.9f)
)
internal data class FontOpt(val label: String, val font: String, val path: String?)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        App.ctx = applicationContext
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = darkColorScheme(primary = TEAL, onPrimary = Color(0xFF06231D), secondary = GOLD, background = BG, surface = PANEL)) { AppRoot() }
            }
        }
    }
}


@OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
fun AppRoot(vm: EditorViewModel = viewModel()) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(1000); splash = false }
    var screen by remember { mutableStateOf(if (vm.projectId != 0L && vm.clips.isNotEmpty()) "editor" else "home") }
    var tab by remember { mutableIntStateOf(0) }
    var items by remember { mutableStateOf(Projects.list(ctx)) }
    var initPrompt by remember { mutableStateOf<String?>(null) }
    var initPanel by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<Pair<String?, String?>?>(null) }
    LaunchedEffect(screen, tab) { if (screen == "home") items = Projects.list(ctx) }
    BackHandler(screen == "home" && tab != 0) { tab = 0 }
    val newPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        val pr = pending; pending = null
        if (u != null) scope.launch {
            vm.busy = "جاري الاستيراد..."
            try {
                val f = withContext(Dispatchers.IO) { importMedia(ctx, u, "src", "video/mp4") }
                val (d, ratio, ok) = withContext(Dispatchers.IO) { videoInfo(f.path) }
                if (ok && d > 0) {
                    vm.autosave(ctx); vm.newProject(); vm.addSource(ctx, Uri.fromFile(f), d, ratio)
                    initPrompt = pr?.first; initPanel = pr?.second; screen = "editor"
                } else vm.status = "تعذر قراءة الفيديو"
            } finally { vm.busy = null }
        }
    }
    fun start(prompt: String?, panel: String?) { pending = prompt to panel; newPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }
    fun open(id: Long) { vm.autosave(ctx); vm.openProject(ctx, id); screen = "editor" }

    Box(Modifier.fillMaxSize().background(BG)) {
        if (screen == "editor") {
            EditorScreen(vm, onExit = { vm.autosave(ctx); items = Projects.list(ctx); screen = "home"; tab = 0 }, initPrompt = initPrompt, initPanel = initPanel) { initPrompt = null; initPanel = null }
        } else {
            when (tab) {
                0 -> HomeScreen(items, onStart = { p, pa -> start(p, pa) }, onOpen = { id -> open(id) }, onAllProjects = { tab = 1 }, onSettings = { tab = 3 })
                1 -> Box(Modifier.fillMaxSize()) {
                    GlowBackground()
                    ProjectsScreen(items, onOpen = { id -> open(id) }, onNew = { start(null, null) },
                        onDelete = { id -> Projects.delete(ctx, id); items = Projects.list(ctx); if (id == vm.projectId) vm.newProject() }, onClose = null)
                }
                2 -> LibraryScreen()
                else -> SettingsScreen()
            }
            BottomNav(tab, { tab = it }, { start(null, "ai") }, Modifier.align(Alignment.BottomCenter))
            vm.busy?.let { b ->
                Text(b, color = Color.White, fontSize = 13.sp, modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 10.dp)
                    .clip(RoundedCornerShape(50)).background(Color(0xE6000000)).padding(horizontal = 16.dp, vertical = 8.dp))
            }
        }
        if (splash) SplashScreen()
    }
}
