package com.example.editfast

import android.graphics.*
import android.media.MediaMetadataRetriever
import java.util.Locale
import android.text.*
import android.text.style.ForegroundColorSpan
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlaySettings
import kotlin.math.*

/** المناطق التي تغطيها واجهة المنصة (نسب تقريبية من الإطار العمودي 9:16) */
data class SafeZone(val top: Float, val bottom: Float, val right: Float, val left: Float = 0.04f)
val PLATFORMS: List<Pair<String, SafeZone?>> = listOf(
    "بدون" to null,
    "TikTok" to SafeZone(0.12f, 0.26f, 0.17f),
    "Instagram Reels" to SafeZone(0.10f, 0.22f, 0.15f),
    "YouTube Shorts" to SafeZone(0.10f, 0.22f, 0.17f)
)
fun presetY(z: SafeZone?, which: Int): Float = when (which) {
    0 -> if (z != null) 1f - 2f * z.top - 0.15f else 0.65f
    1 -> 0.05f
    else -> if (z != null) -1f + 2f * z.bottom + 0.15f else -0.65f
}

val ANIMS = listOf("بدون", "تلاشي", "ظهور مكبّر", "انزلاق من الأسفل", "انزلاق من الأعلى", "آلة كاتبة", "تكبير من الكبير", "دوران", "ارتداد", "كاريوكي (تمييز الكلمات)")
val OUTS = listOf("بدون", "تلاشي", "تصغير", "انزلاق للأسفل", "انزلاق للأعلى")
val LOOPS = listOf("بدون", "نبض", "طفو", "اهتزاز", "وميض")
val TEMPLATES: List<Pair<String, CapStyle>> = listOf(
    "أصفر بارز" to CapStyle(),
    "أبيض كلاسيك" to CapStyle(color = 0xFFFFFFFF.toInt(), anim = 1),
    "صندوق دائري" to CapStyle(color = 0xFFFFFFFF.toInt(), outline = false, shadow = false, boxMode = 2, boxColor = 0xCC000000.toInt(), anim = 1),
    "نيون" to CapStyle(color = 0xFF00E5FF.toInt(), anim = 3),
    "آلة كاتبة" to CapStyle(font = "monospace", color = 0xFFFFFFFF.toInt(), outline = false, boxMode = 1, boxColor = 0xFF000000.toInt(), anim = 5),
    "وردي بوب" to CapStyle(color = 0xFFFF4081.toInt(), outlineColor = 0xFFFFFFFF.toInt(), anim = 2),
    "شريط أخضر" to CapStyle(color = 0xFF000000.toInt(), outline = false, shadow = false, boxMode = 2, boxColor = 0xFF69F0AE.toInt(), anim = 4),
    "كاريوكي" to CapStyle(color = 0xFFFFFFFF.toInt(), anim = 9, hl = 0xFFFFEB3B.toInt(), boxMode = 2, boxColor = 0xCC000000.toInt(), outline = false),
    "ذهبي متدرج" to CapStyle(color = 0xFFFFD54F.toInt(), grad = true, color2 = 0xFFFF6F00.toInt(), anim = 2, shadow = true),
    "نيون متوهج" to CapStyle(color = 0xFF00E5FF.toInt(), outline = false, shadow = false, glow = true, anim = 1, loop = 1),
    "ارتداد مرح" to CapStyle(color = 0xFFFFFFFF.toInt(), outlineColor = 0xFFFF4081.toInt(), anim = 8, loop = 2),
    "تحذير" to CapStyle(color = 0xFFFF1744.toInt(), outlineColor = 0xFFFFFFFF.toInt(), anim = 6, loop = 4, bold = true)
)

data class AnimState(val alpha: Float, val scale: Float, val dy: Float, val chars: Int, val rot: Float = 0f)

object CapAnim {
    private fun easeOut(p: Float) = 1f - (1f - p).pow(3)
    private fun back(p: Float): Float { val c1 = 1.70158f; val c3 = c1 + 1f; return 1f + c3 * (p - 1f).pow(3) + c1 * (p - 1f).pow(2) }
    private fun bounce(p: Float): Float {
        var x = p
        return when {
            x < 1f / 2.75f -> 7.5625f * x * x
            x < 2f / 2.75f -> { x -= 1.5f / 2.75f; 7.5625f * x * x + 0.75f }
            x < 2.5f / 2.75f -> { x -= 2.25f / 2.75f; 7.5625f * x * x + 0.9375f }
            else -> { x -= 2.625f / 2.75f; 7.5625f * x * x + 0.984375f }
        }
    }
    private fun karaoke(c: Caption, t: Long): Int {
        val ends = ArrayList<Int>(); var idx = 0
        for (w in c.text.split(" ")) { idx += w.length; ends.add(idx); idx += 1 }
        if (ends.isEmpty()) return -1
        val p = ((t - c.startMs).toFloat() / max(1L, c.endMs - c.startMs)).coerceIn(0f, 1f)
        val wi = ceil(p * ends.size).toInt().coerceIn(1, ends.size)
        return min(ends[wi - 1], c.text.length)
    }

    /** حالة الحركة عند الزمن t (تُستخدم في المعاينة والتصدير بنفس الطريقة) */
    fun state(c: Caption, t: Long): AnimState {
        val st = c.st; val d = max(1L, st.animMs).toFloat()
        val pin = ((t - c.startMs) / d).coerceIn(0f, 1f); val pout = ((c.endMs - t) / d).coerceIn(0f, 1f)
        var alpha = 1f; var scale = 1f; var dy = 0f; var chars = -1; var rot = st.rot
        when (st.anim) {
            1 -> alpha = pin
            2 -> { scale = 0.5f + 0.5f * back(pin); alpha = min(1f, pin * 3f) }
            3 -> { dy = -(1f - easeOut(pin)) * 0.2f; alpha = pin }
            4 -> { dy = (1f - easeOut(pin)) * 0.2f; alpha = pin }
            5 -> chars = ceil(c.text.length * ((t - c.startMs) / (d * 3f)).coerceIn(0f, 1f)).toInt()
            6 -> { scale = 1f + 0.8f * (1f - easeOut(pin)); alpha = pin }
            7 -> { rot += (1f - easeOut(pin)) * -180f; scale = 0.4f + 0.6f * easeOut(pin); alpha = min(1f, pin * 3f) }
            8 -> dy = (1f - bounce(pin)) * 0.35f
            9 -> chars = karaoke(c, t)
        }
        val t0 = (t - c.startMs) / 1000f
        when (st.loop) {
            1 -> scale *= 1f + 0.06f * sin(t0 * 12.566f)
            2 -> dy += 0.015f * sin(t0 * 6.283f)
            3 -> rot += 3f * sin(t0 * 37.7f)
            4 -> alpha *= 0.55f + 0.45f * (0.5f + 0.5f * sin(t0 * 12.566f))
        }
        when (st.animOut) {
            1 -> alpha *= pout
            2 -> { scale *= 0.5f + 0.5f * pout; alpha *= pout }
            3 -> { dy -= (1f - pout) * 0.2f; alpha *= pout }
            4 -> { dy += (1f - pout) * 0.2f; alpha *= pout }
        }
        if (c.tpl != null) chars = ((t - c.startMs) / 50).toInt().coerceAtLeast(0)
        return AnimState((alpha * st.opacity).coerceIn(0f, 1f), scale.coerceAtLeast(0.01f), dy, chars, rot)
    }

    /** مركز النص بإحداثيات NDC مع حصره داخل المنطقة الآمنة */
    fun place(c: Caption, bw: Int, bh: Int, fw: Int, fh: Int, safe: SafeZone?, a: AnimState): Pair<Float, Float> {
        var x = c.st.x; var y = c.st.y
        if (safe != null) {
            val hw = bw.toFloat() / fw; val hh = bh.toFloat() / fh
            val xmin = -1f + 2f * safe.left + hw; val xmax = 1f - 2f * safe.right - hw
            val ymin = -1f + 2f * safe.bottom + hh; val ymax = 1f - 2f * safe.top - hh
            if (xmin <= xmax) x = x.coerceIn(xmin, xmax)
            if (ymin <= ymax) y = y.coerceIn(ymin, ymax)
        }
        return x to (y + a.dy)
    }
}

object CapRender {
    private val imgCache = HashMap<String, Bitmap>()
    private fun sticker(path: String): Bitmap? = imgCache.getOrPut(path) {
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = 2 }) ?: return null
    }

    /** إزالة اللون الأخضر (كروما) */
    private fun chromaKey(b: Bitmap, tol: Float) {
        val w = b.width; val h = b.height; val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        val lo = 25f; val hi = lo + (1f - tol) * 120f + 10f
        for (i in px.indices) {
            val p = px[i]; val r = (p shr 16) and 255; val g = (p shr 8) and 255; val bl = p and 255
            val d = g - max(r, bl)
            if (g > 60 && d > lo) {
                val a = (1f - (d - lo) / (hi - lo)).coerceIn(0f, 1f)
                px[i] = ((a * 255).toInt() shl 24) or (p and 0xFFFFFF)
            }
        }
        b.setPixels(px, 0, w, 0, 0, w, h)
    }

    /** قناع (دائري/مستدير) + إطار + كروما لصورة أو إطار فيديو */
    fun finish(src: Bitmap, c: Caption): Bitmap {
        if (c.mask == 0 && c.bw <= 0f && !c.chroma) return src
        var b = src.copy(Bitmap.Config.ARGB_8888, true)
        if (c.chroma) chromaKey(b, c.chromaTol)
        if (c.mask != 0 || c.bw > 0f) {
            val out = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888); val cv = Canvas(out)
            val bwPx = c.bw * b.width * 0.01f
            val r = RectF(bwPx / 2, bwPx / 2, b.width - bwPx / 2, b.height - bwPx / 2)
            val path = Path()
            when (c.mask) {
                1 -> path.addOval(r, Path.Direction.CW)
                2 -> path.addRoundRect(r, min(r.width(), r.height()) * 0.18f, min(r.width(), r.height()) * 0.18f, Path.Direction.CW)
                else -> path.addRect(r, Path.Direction.CW)
            }
            cv.save(); cv.clipPath(path); cv.drawBitmap(b, 0f, 0f, null); cv.restore()
            if (c.bw > 0f) cv.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = bwPx; color = c.bc })
            b = out
        }
        return b
    }

    /** يرسم النص (أو الملصق) في صورة بنفس الأبعاد النسبية للإطار: خط، حدود، ظل، توهج، تدرج، صندوق */
    fun render(c: Caption, fw: Int, fh: Int, chars: Int = -1): Bitmap {
        if (c.tpl != null) return TplRender.draw(c, fw, fh, max(0, chars))
        val st = c.st
        if (c.img != null) sticker(c.img)?.let { b ->
            val th = (fh * 0.22f * st.size).toInt().coerceAtLeast(8)
            return finish(Bitmap.createScaledBitmap(b, max(8, b.width * th / b.height), th, true), c)
        }
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = st.typeface(); textSize = fh * 0.04f * st.size; color = st.color; letterSpacing = st.spacing
        }
        val full = c.text.ifBlank { " " }
        val w = min(max(40, (fw * st.maxW).toInt()), max(1, ceil(Layout.getDesiredWidth(full, tp)).toInt()))
        val shown = wrapWords(full, st.wpl)
        val sp = SpannableString(shown)
        if (st.anim == 9 && chars >= 0) sp.setSpan(ForegroundColorSpan(st.hl), 0, min(chars, shown.length), 0)
        else if (st.anim == 5 && chars in 0 until shown.length) sp.setSpan(ForegroundColorSpan(0x00000000), chars, shown.length, 0)
        val al = when (st.align) { 0 -> Layout.Alignment.ALIGN_NORMAL; 2 -> Layout.Alignment.ALIGN_OPPOSITE; else -> Layout.Alignment.ALIGN_CENTER }
        fun lay(p: TextPaint) = StaticLayout.Builder.obtain(sp, 0, sp.length, p, w).setAlignment(al).setLineSpacing(0f, st.lineSp).build()
        val sw = if (st.outline) tp.textSize * 0.14f * st.outW else 0f
        val gp = if (st.glow) tp.textSize * 0.5f else 0f
        val ex = max(sw, gp)
        val pad = if (st.boxMode != 0) tp.textSize * 0.5f * st.boxPad else 0f
        val h = lay(tp).height
        val bw = max(2, (w + 2 * pad + 2 * ex).toInt()); val bh = max(2, (h + 2 * pad + 2 * ex).toInt())
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888); val cv = Canvas(bmp)
        if (st.boxMode != 0) {
            val bp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = st.boxColor }
            val r = RectF(0f, 0f, bw.toFloat(), bh.toFloat())
            if (st.boxMode == 2) cv.drawRoundRect(r, pad * st.boxR, pad * st.boxR, bp) else cv.drawRect(r, bp)
        }
        cv.save(); cv.translate(pad + ex, pad + ex)
        if (st.outline) {
            val op = TextPaint(tp).apply { style = Paint.Style.STROKE; strokeWidth = sw * 2; color = st.outlineColor; strokeJoin = Paint.Join.ROUND }
            lay(op).draw(cv)
        }
        if (st.grad && st.anim != 9) tp.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), st.color, st.color2, Shader.TileMode.CLAMP)
        if (st.glow) tp.setShadowLayer(tp.textSize * 0.5f, 0f, 0f, if (st.glowColor != 0) st.glowColor else st.color)
        else if (st.shadow) tp.setShadowLayer(tp.textSize * 0.12f * st.shadowAmt, 2f, 2f, st.shadowColor)
        tp.isUnderlineText = st.underline
        lay(tp).draw(cv)
        cv.restore(); return bmp
    }
}

/** طبقة تراكب واحدة في التصدير (تعرض نصاً واحداً في كل لحظة) */
@UnstableApi
class LaneOverlay(private val caps: List<Caption>, private val fw: Int, private val fh: Int, private val safe: SafeZone?, private val offsetMs: Long = 0L) : BitmapOverlay() {
    private val blank = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
    private val cache = HashMap<Pair<Int, Int>, Bitmap>()
    private val lastVid = HashMap<Int, Pair<Long, Bitmap>>()
    private fun cur(ms: Long) = caps.indexOfFirst { ms >= it.startMs && ms <= it.endMs }

    /** إطار فيديو التراكب (PIP) بدقة 15 إطاراً/ث */
    private fun vidBitmap(i: Int, ms: Long): Bitmap {
        val c = caps[i]; val wPx = max(8, (fw * 0.45f * c.st.size).toInt()); val hPx = max(8, (wPx / c.vAspect).toInt())
        val q = (max(0L, ms - c.startMs + c.srcStart) / 66) * 66
        lastVid[i]?.let { if (it.first == q) return it.second }
        val raw = PipFrames.frame(c.vid!!, q, wPx, hPx)
        val out = if (raw == null) blank else CapRender.finish(raw, c)
        lastVid[i] = q to out; return out
    }

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val ms = presentationTimeUs / 1000 + offsetMs; val i = cur(ms); if (i < 0) return blank
        if (caps[i].vid != null) return vidBitmap(i, ms)
        val a = CapAnim.state(caps[i], ms)
        return cache.getOrPut(i to a.chars) { CapRender.render(caps[i], fw, fh, a.chars) }
    }
    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val ms = presentationTimeUs / 1000 + offsetMs; val i = cur(ms)
        if (i < 0) return OverlaySettings.Builder().setAlphaScale(0f).build()
        val a = CapAnim.state(caps[i], ms); val b = getBitmap(presentationTimeUs)
        val (x, y) = CapAnim.place(caps[i], b.width, b.height, fw, fh, safe, a)
        return OverlaySettings.Builder().setOverlayFrameAnchor(0f, 0f).setBackgroundFrameAnchor(x, y)
            .setScale(a.scale, a.scale).setAlphaScale(a.alpha).setRotationDegrees(a.rot).build()
    }
}

/** توزيع النصوص المتزامنة على طبقات بحيث لا يتداخل نصان في الطبقة نفسها */
fun captionLanes(caps: List<Caption>): List<List<Caption>> {
    val out = mutableListOf<MutableList<Caption>>()
    for (c in caps.sortedBy { it.startMs }) {
        val l = out.firstOrNull { it.last().endMs <= c.startMs } ?: mutableListOf<Caption>().also { out.add(it) }
        l.add(c)
    }
    return out
}

/** استخراج إطارات فيديو التراكب أثناء التصدير */
object PipFrames {
    private val mmr = HashMap<String, MediaMetadataRetriever>()
    fun frame(path: String, tMs: Long, w: Int, h: Int): Bitmap? = try {
        val r = mmr.getOrPut(path) { MediaMetadataRetriever().apply { setDataSource(path) } }
        r.getScaledFrameAtTime(tMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST, w, h)
    } catch (e: Exception) { null }
    fun release() { mmr.values.forEach { runCatching { it.release() } }; mmr.clear() }
}

/** رقم الطبقة (0..2) لكل عنصر حتى لا تتداخل الكتل المتزامنة في الخط الزمني */
fun laneIndex(caps: List<Caption>): IntArray {
    val res = IntArray(caps.size); val ends = mutableListOf<Long>()
    for (i in caps.indices.sortedBy { caps[it].startMs }) {
        var l = ends.indexOfFirst { it <= caps[i].startMs }
        if (l < 0) { ends.add(caps[i].endMs); l = ends.lastIndex } else ends[l] = caps[i].endMs
        res[i] = min(l, 2)
    }
    return res
}

/** قوالب موشن جرافيكس تُرسم برمجياً وتتحرك بحسب الزمن (معاينة وتصدير بنفس الكود) */
object TplRender {
    val LIST = listOf("lower" to "ثلث سفلي", "subscribe" to "زر اشتراك", "social" to "لايك وكومنت وشير",
        "counter" to "عدّاد", "title" to "عنوان متحرك", "frame" to "إطار تمييز")
    fun defaults(id: String): Triple<String, String, Int> = when (id) {
        "lower" -> Triple("اسمك هنا", "المسمى الوظيفي", 0xFFFF3B5C.toInt())
        "subscribe" -> Triple("اشترك", "تم الاشتراك", 0xFFFF1744.toInt())
        "social" -> Triple("", "", 0xFFFF1744.toInt())
        "counter" -> Triple("1500K", "متابع", 0xFF69F0AE.toInt())
        "title" -> Triple("عنوان كبير", "", 0xFFFFEB3B.toInt())
        else -> Triple("انتبه هنا", "", 0xFFFFEB3B.toInt())
    }
    private fun ease(p: Float) = 1f - (1f - p).pow(3)
    private fun back(p: Float): Float { val c1 = 1.70158f; val c3 = c1 + 1f; return 1f + c3 * (p - 1f).pow(3) + c1 * (p - 1f).pow(2) }
    private fun bmp(w: Float, h: Float) = Bitmap.createBitmap(max(2, w.toInt()), max(2, h.toInt()), Bitmap.Config.ARGB_8888)

    fun draw(c: Caption, fw: Int, fh: Int, frame: Int): Bitmap {
        val t = frame * 50L; val dur = max(1L, c.endMs - c.startMs)
        val inP = ease((t / 450f).coerceIn(0f, 1f)); val outP = ease(((dur - t) / 350f).coerceIn(0f, 1f))
        val k = c.st.size; val u = fh * 0.04f * k; val acc = c.bc
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = c.st.typeface(); color = c.st.color }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        when (c.tpl) {
            "lower" -> {
                val w = fw * 0.8f * k; val h = u * 4.6f; val b = bmp(w, h); val cv = Canvas(b)
                val barW = w * min(inP, outP)
                if (barW > 2f) {
                    cv.save(); cv.clipRect(w - barW, 0f, w, h)
                    fill.color = 0xE6101018.toInt(); cv.drawRoundRect(RectF(0f, 0f, w, h), u * 0.4f, u * 0.4f, fill)
                    fill.color = acc; cv.drawRect(w - u * 0.5f, 0f, w, h, fill)
                    tp.textAlign = Paint.Align.RIGHT; tp.isFakeBoldText = true; tp.textSize = u * 1.6f
                    cv.drawText(c.text, w - u * 1.1f, u * 2.1f, tp)
                    tp.isFakeBoldText = false; tp.textSize = u * 1.05f; tp.alpha = 200
                    cv.drawText(c.t2, w - u * 1.1f, u * 3.7f, tp)
                    cv.restore()
                }
                return b
            }
            "subscribe" -> {
                val w = u * 10f; val h = u * 4.2f; val b = bmp(w, h); val cv = Canvas(b)
                val done = t > 1500; val sc = if (t < 450) back(inP) else 1f
                cv.save(); cv.scale(sc, sc, w / 2, h / 2)
                fill.color = if (done) 0xFF555560.toInt() else acc
                cv.drawRoundRect(RectF(u * 0.3f, u * 0.3f, w - u * 0.3f, h - u * 0.3f), h / 2, h / 2, fill)
                tp.textAlign = Paint.Align.CENTER; tp.textSize = u * 1.7f; tp.isFakeBoldText = true
                cv.drawText(if (done) c.t2 else c.text, w / 2, h / 2 + tp.textSize * 0.33f, tp)
                if (t in 900..1500) { val q = (t - 900) / 600f; fill.color = Color.argb(40 + (120 * (1 - q)).toInt(), 255, 255, 255); cv.drawCircle(w * 0.72f, h * 0.62f, u * (0.6f + q * 0.9f), fill) }
                cv.restore(); return b
            }
            "social" -> {
                val w = u * 13f; val h = u * 4.4f; val b = bmp(w, h); val cv = Canvas(b); val r = u * 1.15f
                for (i in 0..2) {
                    val cx = w * (2 * i + 1) / 6f; val cy = h / 2; val win = t - i * 450L
                    val pulse = if (win in 0..450) sin(PI * win / 450.0).toFloat() else 0f
                    val s = (1f + 0.35f * pulse) * inP.coerceAtLeast(0.01f)
                    cv.save(); cv.scale(s, s, cx, cy)
                    when (i) {
                        0 -> {
                            fill.color = if (win >= 0) 0xFFFF1744.toInt() else Color.WHITE
                            val p = Path(); p.moveTo(cx, cy + r * 0.95f)
                            p.cubicTo(cx - r * 1.7f, cy - r * 0.1f, cx - r * 0.8f, cy - r * 1.3f, cx, cy - r * 0.35f)
                            p.cubicTo(cx + r * 0.8f, cy - r * 1.3f, cx + r * 1.7f, cy - r * 0.1f, cx, cy + r * 0.95f)
                            p.close(); cv.drawPath(p, fill)
                        }
                        1 -> {
                            fill.color = Color.WHITE
                            cv.drawRoundRect(RectF(cx - r, cy - r * 0.85f, cx + r, cy + r * 0.55f), r * 0.4f, r * 0.4f, fill)
                            val tail = Path(); tail.moveTo(cx - r * 0.45f, cy + r * 0.5f); tail.lineTo(cx - r * 0.75f, cy + r * 1.1f); tail.lineTo(cx, cy + r * 0.5f); tail.close()
                            cv.drawPath(tail, fill)
                        }
                        else -> {
                            fill.color = Color.WHITE
                            val a = Path(); a.moveTo(cx + r, cy - r * 0.05f); a.lineTo(cx + r * 0.1f, cy - r * 0.9f); a.lineTo(cx + r * 0.1f, cy - r * 0.4f)
                            a.cubicTo(cx - r * 0.8f, cy - r * 0.35f, cx - r, cy + r * 0.2f, cx - r * 1.05f, cy + r * 0.9f)
                            a.cubicTo(cx - r * 0.45f, cy + r * 0.3f, cx - r * 0.1f, cy + r * 0.15f, cx + r * 0.1f, cy + r * 0.2f)
                            a.lineTo(cx + r * 0.1f, cy + r * 0.75f); a.close(); cv.drawPath(a, fill)
                        }
                    }
                    cv.restore()
                }
                return b
            }
            "counter" -> {
                val target = c.text.filter { it.isDigit() }.toLongOrNull() ?: 100L
                val suffix = c.text.dropWhile { it.isDigit() || it == ',' }.trim()
                val p = ease((t / 1600f).coerceIn(0f, 1f))
                val shown = String.format(Locale.US, "%,d", (target * p).toLong()) + suffix
                tp.isFakeBoldText = true; tp.textSize = u * 4.2f; val w1 = tp.measureText(shown)
                tp.textSize = u * 1.4f; val w2 = tp.measureText(c.t2)
                val w = max(w1, w2) + u * 1.6f; val h = u * 7.2f; val b = bmp(w, h); val cv = Canvas(b)
                val a = (255 * min(inP, outP)).toInt()
                tp.textAlign = Paint.Align.CENTER; tp.textSize = u * 4.2f; tp.alpha = a
                val ol = TextPaint(tp).apply { style = Paint.Style.STROKE; strokeWidth = u * 0.3f; color = 0xFF000000.toInt(); alpha = a }
                cv.drawText(shown, w / 2, u * 4.4f, ol); cv.drawText(shown, w / 2, u * 4.4f, tp)
                tp.textSize = u * 1.4f; tp.color = acc; tp.alpha = a; cv.drawText(c.t2, w / 2, u * 6.4f, tp)
                return b
            }
            "title" -> {
                tp.isFakeBoldText = true; tp.textSize = u * 2.6f; val tw = tp.measureText(c.text)
                val w = tw + u * 2f; val h = u * 4.4f; val b = bmp(w, h); val cv = Canvas(b)
                val a = min(inP, outP); tp.alpha = (255 * a).toInt()
                cv.drawText(c.text, u, u * 2.8f + (1f - inP) * u * 1.2f, tp)
                fill.color = acc; cv.drawRect(u, u * 3.4f, u + tw * a, u * 3.7f, fill)
                return b
            }
            else -> {
                val w = fw * 0.5f * k; val h = w * 0.55f; val b = bmp(w, h); val cv = Canvas(b)
                val pad = u * 0.4f; val rect = RectF(pad, pad + u * 1.4f, w - pad, h - pad)
                val path = Path(); path.addRoundRect(rect, u * 0.6f, u * 0.6f, Path.Direction.CW)
                val pm = PathMeasure(path, false); val seg = Path(); pm.getSegment(0f, pm.length * inP, seg, true)
                val pulse = if (t > 600) 0.7f + 0.3f * sin(t / 180.0).toFloat() else 1f
                val st = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = u * 0.28f; color = acc; alpha = (255 * pulse * outP).toInt() }
                cv.drawPath(seg, st)
                if (c.text.isNotBlank() && inP > 0.5f) {
                    tp.textSize = u * 1.1f; tp.isFakeBoldText = true; tp.color = 0xFF000000.toInt()
                    val tw = tp.measureText(c.text); fill.color = acc
                    cv.drawRoundRect(RectF(pad, pad, pad + tw + u, pad + u * 1.3f), u * 0.3f, u * 0.3f, fill)
                    cv.drawText(c.text, pad + u * 0.5f, pad + u * 1.0f, tp)
                }
                return b
            }
        }
    }
}

/** يقسم النص إلى أسطر بعدد كلمات ثابت في كل سطر. n = 0 يعني تلقائي (لا تغيير). الأسطر الفارغة تُحفظ. */
fun wrapWords(text: String, n: Int): String {
    if (n <= 0) return text
    return text.lines().joinToString("\n") { line ->
        line.split(Regex("\\s+")).filter { it.isNotEmpty() }.chunked(n).joinToString("\n") { it.joinToString(" ") }
    }
}
