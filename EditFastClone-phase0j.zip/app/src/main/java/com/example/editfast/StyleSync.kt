package com.example.editfast

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** مجموعات خصائص التنسيق التي يمكن نسخها من نص إلى كل النصوص */
enum class StyleGroup(val label: String, val hint: String) {
    FONT("الخط", "نوع الخط، عريض، مائل، تسطير"),
    SIZE("الحجم", "حجم النص"),
    COLOR("الألوان", "لون النص والتعبئة المتدرجة"),
    STROKE("الحدود والظل", "الحدود، الظل، التوهج"),
    BOX("الخلفية (الصندوق)", "نوع الخلفية، لونها، حشوتها، استدارتها"),
    LAYOUT("المحاذاة والتباعد", "المحاذاة، تباعد الأحرف والأسطر، أقصى عرض"),
    ANIM("الحركة", "حركة الظهور والاختفاء"),
    POSITION("الموضع والشفافية", "موضع النص، تدويره، شفافيته")
}

/** ينسخ المجموعات المحددة من [src] إلى هذا التنسيق، والباقي يبقى كما هو */
fun CapStyle.copyGroups(src: CapStyle, groups: Set<StyleGroup>): CapStyle {
    var r = this
    if (StyleGroup.FONT in groups) r = r.copy(font = src.font, fontPath = src.fontPath, bold = src.bold, italic = src.italic, underline = src.underline)
    if (StyleGroup.SIZE in groups) r = r.copy(size = src.size)
    if (StyleGroup.COLOR in groups) r = r.copy(color = src.color, grad = src.grad, color2 = src.color2)
    if (StyleGroup.STROKE in groups) r = r.copy(
        outline = src.outline, outlineColor = src.outlineColor, outW = src.outW,
        shadow = src.shadow, shadowAmt = src.shadowAmt, shadowColor = src.shadowColor, glow = src.glow, glowColor = src.glowColor
    )
    if (StyleGroup.BOX in groups) r = r.copy(boxMode = src.boxMode, boxColor = src.boxColor, boxPad = src.boxPad, boxR = src.boxR)
    if (StyleGroup.LAYOUT in groups) r = r.copy(align = src.align, spacing = src.spacing, lineSp = src.lineSp, maxW = src.maxW, wpl = src.wpl)
    if (StyleGroup.ANIM in groups) r = r.copy(anim = src.anim, animOut = src.animOut, loop = src.loop, animMs = src.animMs)
    if (StyleGroup.POSITION in groups) r = r.copy(x = src.x, y = src.y, rot = src.rot, opacity = src.opacity)
    return r
}

/** ينطبق على نصوص الكابشن فقط: يستثني الملصقات والتراكب والقوالب الموشن. يعيد عدد النصوص المعدّلة. */
fun EditorViewModel.isTextCaption(i: Int): Boolean {
    val c = captions.getOrNull(i) ?: return false
    return c.img == null && c.vid == null && c.tpl == null
}

fun EditorViewModel.applyGroupsToAll(src: CapStyle, groups: Set<StyleGroup>): Int {
    if (groups.isEmpty()) return 0
    val targets = captions.indices.filter { isTextCaption(it) }
    if (targets.isEmpty()) return 0
    push()
    for (k in targets) captions[k] = captions[k].copy(st = captions[k].st.copyGroups(src, groups))
    defStyle = defStyle.copyGroups(src, groups)
    return targets.size
}

/** لوحة «تنسيق الكل»: تختار المصدر (النص المحدد أو الافتراضي) والمجموعات، ثم تطبّقها على كل النصوص */
@Composable
fun ApplyAllPanel(vm: EditorViewModel) {
    val sel = vm.captions.getOrNull(vm.selCap)
    val src = sel?.st ?: vm.defStyle
    val targets = vm.captions.indices.count { vm.isTextCaption(it) }
    var groups by remember { mutableStateOf(setOf(StyleGroup.FONT, StyleGroup.SIZE, StyleGroup.COLOR, StyleGroup.STROKE)) }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(
            if (sel != null) "المصدر: تنسيق النص «${sel.text.take(20)}»" else "المصدر: التنسيق الافتراضي (حدّد نصاً لنسخ تنسيقه)",
            color = Color.White, fontSize = 13.sp
        )
        Text("اختر ما تريد نسخه إلى $targets نص", color = Color(0xFF8E87A0), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        StyleGroup.values().forEach { g ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = g in groups, onCheckedChange = { on -> groups = if (on) groups + g else groups - g })
                Column(Modifier.padding(start = 4.dp)) {
                    Text(g.label, color = Color.White, fontSize = 14.sp)
                    Text(g.hint, color = Color(0xFF8E87A0), fontSize = 11.sp)
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton({ groups = StyleGroup.values().toSet() }) { Text("تحديد الكل") }
            TextButton({ groups = emptySet() }) { Text("إلغاء التحديد") }
        }
        Button(
            onClick = {
                val n = vm.applyGroupsToAll(src, groups)
                vm.status = if (n == 0) "لا توجد نصوص لتطبيق التنسيق عليها" else "تم تطبيق التنسيق على $n نص (تراجع متاح)"
            },
            enabled = groups.isNotEmpty() && targets > 0,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        ) { Text("تطبيق على الكل") }
    }
}
