package com.example.editfast

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** خلفية جاهزة: تدرج لوني بين لونين وزاوية. مولّدة في الكود فلا تحتاج ملفات أو تراخيص. */
data class BgPreset(val id: String, val name: String, val from: Int, val to: Int, val angleDeg: Float = 90f)

val BG_PRESETS = listOf(
    BgPreset("sunset", "غروب", 0xFFFF7E5F.toInt(), 0xFFFEB47B.toInt()),
    BgPreset("ocean", "محيط", 0xFF2E3192.toInt(), 0xFF1BFFFF.toInt()),
    BgPreset("night", "ليل", 0xFF0F2027.toInt(), 0xFF2C5364.toInt()),
    BgPreset("mint", "نعناع", 0xFF11998E.toInt(), 0xFF38EF7D.toInt()),
    BgPreset("royal", "ملكي", 0xFF41295A.toInt(), 0xFF2F0743.toInt()),
    BgPreset("gold", "ذهبي", 0xFFF7D98A.toInt(), 0xFFE8B84B.toInt()),
    BgPreset("rose", "وردي", 0xFFEE9CA7.toInt(), 0xFFFFDDE1.toInt()),
    BgPreset("black", "أسود", 0xFF000000.toInt(), 0xFF2A2A2A.toInt()),
    BgPreset("white", "أبيض", 0xFFFFFFFF.toInt(), 0xFFE6E6E6.toInt())
)

/** يرسم التدرج بحجم w×h. الزاوية 90 تعني من الأعلى إلى الأسفل. */
fun BgPreset.render(w: Int, h: Int): Bitmap {
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val rad = Math.toRadians(angleDeg.toDouble())
    val cx = w / 2f
    val cy = h / 2f
    val half = (abs(w * cos(rad)) + abs(h * sin(rad))).toFloat() / 2f
    val dx = (cos(rad) * half).toFloat()
    val dy = (sin(rad) * half).toFloat()
    val paint = Paint().apply {
        shader = LinearGradient(cx - dx, cy - dy, cx + dx, cy + dy, from, to, Shader.TileMode.CLAMP)
    }
    Canvas(bmp).drawPaint(paint)
    return bmp
}
