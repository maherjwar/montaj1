package com.example.editfast

import android.annotation.SuppressLint
import android.content.Context
import android.media.*
import android.net.Uri
import org.json.JSONObject
import java.io.*
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import kotlin.math.*
import kotlin.random.Random

data class Seg(val s: Long, val e: Long)
data class Word(val s: Long, val e: Long, val t: String)

object Auto {
    /** تقسيم الكلمات إلى كابشن قصيرة (٣ كلمات كحد أقصى) */
    fun captions(w: List<Word>, perLine: Int = 3): List<Caption> {
        val out = mutableListOf<Caption>(); val cur = mutableListOf<Word>()
        fun flush() {
            if (cur.isNotEmpty()) {
                out += Caption(cur.first().s, max(cur.last().e, cur.first().s + 300), cur.joinToString(" ") { it.t }); cur.clear()
            }
        }
        for (x in w) { if (cur.isNotEmpty() && (x.s - cur.last().e > 500 || cur.size >= max(1, perLine))) flush(); cur.add(x) }
        flush(); return out
    }

    /** قص السكتات: أي فراغ بين كلمتين أطول من gap يُحذف */
    fun segments(w: List<Word>, total: Long, gap: Long = 450, pad: Long = 120): List<Seg> {
        val raw = mutableListOf<Seg>(); var s = w[0].s; var e = w[0].e
        for (x in w.drop(1)) { if (x.s - e > gap) { raw.add(Seg(s, e)); s = x.s }; e = x.e }
        raw.add(Seg(s, e))
        return raw.map { Seg(max(0L, it.s - pad), min(total, it.e + pad)) }
    }

    private fun extractAudio(ctx: Context, uri: Uri, out: File) {
        val ex = MediaExtractor(); ex.setDataSource(ctx, uri, null)
        val idx = (0 until ex.trackCount).first { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/") }
        ex.selectTrack(idx)
        val mux = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val t = mux.addTrack(ex.getTrackFormat(idx)); mux.start()
        val buf = ByteBuffer.allocate(1 shl 20); val info = MediaCodec.BufferInfo()
        while (true) {
            val n = ex.readSampleData(buf, 0); if (n < 0) break
            info.set(0, n, ex.sampleTime, if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
            mux.writeSampleData(t, buf, info); ex.advance()
        }
        mux.stop(); mux.release(); ex.release()
    }

    /** تفريغ الكلام مع توقيت كل كلمة عبر Whisper (Groq مجاني) */
    fun transcribe(ctx: Context, uri: Uri, key: String, lang: String, baseUrl: String = ""): List<Word> {
        val f = File(ctx.cacheDir, "a.m4a"); extractAudio(ctx, uri, f)
        val b = "----ef${System.currentTimeMillis()}"
        val base = baseUrl.ifBlank { "https://api.groq.com/openai/v1" }.trimEnd('/')
        val c = URL("$base/audio/transcriptions").openConnection() as HttpURLConnection
        var code = 0; var body = ""
        try {
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 30000; c.readTimeout = 180000
            c.setRequestProperty("Authorization", "Bearer $key")
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$b")
            c.outputStream.use { o ->
                fun field(n: String, v: String) { o.write("--$b\r\nContent-Disposition: form-data; name=\"$n\"\r\n\r\n$v\r\n".toByteArray()) }
                field("model", "whisper-large-v3-turbo"); field("response_format", "verbose_json")
                field("timestamp_granularities[]", "word")
                if (lang.isNotBlank()) field("language", lang)
                o.write("--$b\r\nContent-Disposition: form-data; name=\"file\"; filename=\"a.m4a\"\r\nContent-Type: audio/mp4\r\n\r\n".toByteArray())
                f.inputStream().use { it.copyTo(o) }; o.write("\r\n--$b--\r\n".toByteArray())
            }
            code = c.responseCode
            body = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
            if (code !in 200..299) throw Exception("خطأ $code: ${body.take(150)}")
        } catch (e: IOException) { throw Exception("تعذر الاتصال بخدمة تحويل الكلام. قد تكون محجوبة في شبكتك أو بلدك (جرّب VPN أو غيّر عنوان الخدمة في الإعدادات)") }
        val arr = JSONObject(body).optJSONArray("words") ?: return emptyList()
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Word((o.getDouble("start") * 1000).toLong(), (o.getDouble("end") * 1000).toLong(), o.getString("word").trim())
        }
    }
}

/** مؤثرات صوتية تُولَّد برمجياً (بدون ملفات) */
object Sfx {
    const val SR = 44100
    fun whoosh(): ShortArray {
        val n = (SR * 0.45).toInt(); val r = Random(1); var lp = 0f
        return ShortArray(n) { i ->
            val t = i / n.toFloat(); val a = sin(PI * t).pow(2).toFloat()
            lp += (0.02f + 0.5f * t) * ((r.nextFloat() * 2 - 1) - lp)
            (lp * a * 32767f * 1.8f).coerceIn(-32767f, 32767f).toInt().toShort()
        }
    }
    fun pop(): ShortArray {
        val n = (SR * 0.12).toInt()
        return ShortArray(n) { i ->
            val t = i / SR.toDouble()
            (sin(2 * PI * max(200.0, 900 - 5000 * t) * t) * exp(-t * 40) * 0.6 * 32767).toInt().toShort()
        }
    }
    /** يدمج المؤثرات في ملف WAV بطول الفيديو الناتج */
    fun render(ctx: Context, totalMs: Long, ev: List<Triple<Long, ShortArray, Float>>): File {
        val n = (totalMs * SR / 1000).toInt(); val mix = IntArray(n)
        for ((t, a, g) in ev) {
            val st = (max(0L, t) * SR / 1000).toInt()
            for (i in a.indices) { val k = st + i; if (k in 0 until n) mix[k] += (a[i] * g).toInt() }
        }
        val f = File(ctx.cacheDir, "sfx.wav")
        DataOutputStream(BufferedOutputStream(f.outputStream())).use { o ->
            val len = n * 4
            fun le32(v: Int) { o.write(v and 255); o.write(v shr 8 and 255); o.write(v shr 16 and 255); o.write(v shr 24 and 255) }
            fun le16(v: Int) { o.write(v and 255); o.write(v shr 8 and 255) }
            o.writeBytes("RIFF"); le32(36 + len); o.writeBytes("WAVEfmt "); le32(16); le16(1); le16(2)
            le32(SR); le32(SR * 4); le16(4); le16(16); o.writeBytes("data"); le32(len)
            for (i in 0 until n) { val v = mix[i].coerceIn(-32767, 32767); le16(v); le16(v) }
        }
        return f
    }
}

/** تسجيل تعليق صوتي (PCM 44.1kHz أحادي) يُدمج لاحقاً في مسار الصوت */
class VoiceRec {
    private var rec: AudioRecord? = null
    private var th: Thread? = null
    @Volatile private var running = false
    private val chunks = mutableListOf<ShortArray>()

    @SuppressLint("MissingPermission")
    fun start() {
        chunks.clear()
        val minB = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(MediaRecorder.AudioSource.MIC, 44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minB * 2)
        rec = r; running = true; r.startRecording()
        th = Thread {
            val buf = ShortArray(minB)
            while (running) { val n = r.read(buf, 0, buf.size); if (n > 0) synchronized(chunks) { chunks.add(buf.copyOf(n)) } }
        }.also { it.start() }
    }

    fun stop(): ShortArray {
        running = false; th?.join(); rec?.stop(); rec?.release(); rec = null
        val out = ShortArray(chunks.sumOf { it.size }); var p = 0
        for (c in chunks) { c.copyInto(out, p); p += c.size }
        return out
    }
}
