package com.example.editfast

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Paint
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.SegmentationMask
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions

/**
 * إزالة خلفية الأشخاص عبر ML Kit (نموذج على الجهاز، يعمل دون إنترنت).
 * المرحلة الحالية: قناع لصورة واحدة وتركيبها على خلفية. ربطها بالمعاينة والتصدير لاحقاً.
 */
object PersonSegmenter {
    private val segmenter by lazy {
        Segmentation.getClient(
            SelfieSegmenterOptions.Builder()
                .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
                .enableRawSizeMask()
                .build()
        )
    }

    /** يعيد قناعاً بحجم الصورة: الأبيض مع ألفا عالٍ = شخص، والشفاف = خلفية. يعيد null عند الفشل. */
    fun mask(bmp: Bitmap, onResult: (Bitmap?) -> Unit) {
        segmenter.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { m -> onResult(toMaskBitmap(m, bmp.width, bmp.height)) }
            .addOnFailureListener { onResult(null) }
    }

    private fun toMaskBitmap(m: SegmentationMask, w: Int, h: Int): Bitmap {
        val buf = m.buffer
        buf.rewind()
        val n = m.width * m.height
        val px = IntArray(n)
        for (i in 0 until n) {
            val a = (buf.float.coerceIn(0f, 1f) * 255f).toInt()
            px[i] = (a shl 24) or 0x00FFFFFF
        }
        val small = Bitmap.createBitmap(px, m.width, m.height, Bitmap.Config.ARGB_8888)
        return Bitmap.createScaledBitmap(small, w, h, true)
    }
}

/** يركّب الشخص (fg) فوق خلفية (bg) باستخدام القناع. الناتج بحجم fg. */
fun composeOver(fg: Bitmap, personMask: Bitmap, bg: Bitmap): Bitmap {
    val w = fg.width
    val h = fg.height
    val person = fg.copy(Bitmap.Config.ARGB_8888, true)
    Canvas(person).drawBitmap(personMask, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) })
    val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = Canvas(out)
    c.drawBitmap(bg, null, Rect(0, 0, w, h), null)
    c.drawBitmap(person, 0f, 0f, null)
    return out
}
