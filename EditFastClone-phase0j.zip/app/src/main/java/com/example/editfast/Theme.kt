package com.example.editfast

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

val BG = Color(0xFF0B0A12)
val PANEL = Color(0xFF14111C)
val CARD = Color(0xFF181421)
val ACCENT = Color(0xFF8B5CF6)
val RED = Color(0xFFFF3B5C)
val GREEN = Color(0xFF7CB342)
val GOLD = Color(0xFFF2C66D)
val TEAL = Color(0xFF3FD8BC)
val PINK = Color(0xFFE96CB5)
val RING = listOf(TEAL, ACCENT, PINK, GOLD, TEAL)

/** زر الذكاء الاصطناعي: حلقة متدرجة وشرارة في المنتصف */
@Composable
fun AiRing(size: Dp, modifier: Modifier = Modifier) {
    Box(modifier.size(size).clip(CircleShape).background(Brush.sweepGradient(RING)), contentAlignment = Alignment.Center) {
        Box(Modifier.size(size - 6.dp).clip(CircleShape).background(Color(0xFF2A1E36)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(size * 0.45f))
        }
    }
}

/** شعار لمسة: حرف L مع نقطة اللمس */
@Composable
fun LogoMark(size: Dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension; val k = s / 108f
        drawRoundRect(Brush.linearGradient(listOf(Color(0xFF6D4AFF), Color(0xFFFF3B5C))), cornerRadius = CornerRadius(s * 0.26f))
        val p = Path().apply { moveTo(40 * k, 26 * k); lineTo(40 * k, 60 * k); quadraticBezierTo(40 * k, 74 * k, 54 * k, 74 * k); lineTo(64 * k, 74 * k) }
        drawPath(p, Color.White, style = Stroke(12 * k, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(Color(0xFFFFD54F), 5.5f * k, Offset(74 * k, 74 * k))
        drawCircle(Color(0xCCFFFFFF), 12 * k, Offset(74 * k, 74 * k), style = Stroke(2.6f * k))
        drawCircle(Color(0x66FFFFFF), 18 * k, Offset(74 * k, 74 * k), style = Stroke(2f * k))
    }
}

/** خلفية داكنة بتوهج بنفسجي وأخضر خفيف */
@Composable
fun GlowBackground(modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxSize().background(BG)) {
        drawCircle(Brush.radialGradient(listOf(Color(0x66B03A72), Color.Transparent), center = Offset(size.width * 0.15f, size.height * 0.08f), radius = size.width * 0.8f),
            radius = size.width * 0.8f, center = Offset(size.width * 0.15f, size.height * 0.08f))
        drawCircle(Brush.radialGradient(listOf(Color(0x4400B88A), Color.Transparent), center = Offset(size.width * 0.95f, size.height * 0.3f), radius = size.width * 0.7f),
            radius = size.width * 0.7f, center = Offset(size.width * 0.95f, size.height * 0.3f))
    }
}

@Composable
fun SplashScreen() {
    val tr = rememberInfiniteTransition(label = "s")
    val sc by tr.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "sc")
    Box(Modifier.fillMaxSize().background(BG), contentAlignment = Alignment.Center) {
        GlowBackground()
        Box(Modifier.size(210.dp).scale(sc).clip(CircleShape).background(Brush.sweepGradient(RING)), contentAlignment = Alignment.Center) {
            Box(Modifier.size(206.dp).clip(CircleShape).background(BG), contentAlignment = Alignment.Center) { LogoMark(120.dp) }
        }
    }
}
